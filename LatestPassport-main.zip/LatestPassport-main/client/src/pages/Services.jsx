export default function Services() {
    return (
      <div>
        <h1>Services</h1>
        <p>Welcome to the Services page!</p>
      </div>
    );
  }